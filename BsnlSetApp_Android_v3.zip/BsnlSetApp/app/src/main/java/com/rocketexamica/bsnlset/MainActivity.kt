package com.rocketexamica.bsnlset

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.webkit.*
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.rocketexamica.bsnlset.databinding.ActivityMainBinding

data class NavItem(val title: String, val file: String, val icon: String)

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private var currentFile = "bsnlset/index.html"

    // ── Navigation Catalogue ──────────────────────────────────────────────────
    private val navSections: List<Pair<String, List<NavItem>>> = listOf(
        "🏠 Home" to listOf(
            NavItem("BSNL SET 2026 Home", "bsnlset/index.html", "🏠"),
            NavItem("Mock Test Dashboard", "bsnlset/paper.html", "📋")
        ),
        "📡 Telecom (Core)" to listOf(
            NavItem("Basic & Wireless Communication", "bsnlset/bwc.html", "📶"),
            NavItem("GSM, 3G, 4G LTE & 5G",           "bsnlset/gsm.html", "📱"),
            NavItem("OFC, FTTH & GPON",                "bsnlset/ofc.html", "🔆"),
            NavItem("Switching Systems & NGN",         "bsnlset/sst.html", "🔀"),
            NavItem("IP / Data Networks",              "bsnlset/ipd.html", "🌐"),
            NavItem("Network Security",                "bsnlset/nt.html",  "🔒"),
            NavItem("Cloud Computing & IoT",           "bsnlset/ct.html",  "☁️"),
            NavItem("IoT, AI & Emerging Tech",         "bsnlset/iot.html", "🤖"),
            NavItem("Satellite Communication",         "bsnlset/sat.html", "🛰️"),
            NavItem("Project Management",              "bsnlset/pm.html",  "📋"),
            NavItem("Business & Entrepreneurship",     "bsnlset/be.html",  "💼")
        ),
        "⚡ Electronics" to listOf(
            NavItem("Analog & Digital Electronics",    "bsnlset/ad.html",  "⚡"),
            NavItem("Electronic Circuits",             "bsnlset/ec.html",  "🔧"),
            NavItem("Solid State Devices",             "bsnlset/ss.html",  "💡"),
            NavItem("Communication Systems",           "bsnlset/cs.html",  "📻"),
            NavItem("Control Systems & Feedback",      "bsnlset/csf.html", "🎛️"),
            NavItem("Power Electronics",               "bsnlset/pe.html",  "🔋"),
            NavItem("Electromagnetic Theory",          "bsnlset/em.html",  "🧲"),
            NavItem("Power Systems",                   "bsnlset/ps.html",  "⚙️"),
            NavItem("Measurement & Instrumentation",   "bsnlset/mes.html", "📏"),
            NavItem("Microprocessors & Microcontrollers","bsnlset/mp.html","🖥️"),
            NavItem("Microelectronics",                "bsnlset/me.html",  "🔬"),
            NavItem("Computer Organisation",           "bsnlset/cos.html", "💻")
        ),
        "💰 Finance & Accounts" to listOf(
            NavItem("Accounting & Reporting",          "bsnlset/ar.html",  "📊"),
            NavItem("Financial Statements Analysis",   "bsnlset/fsa.html", "📈"),
            NavItem("Financial Management",            "bsnlset/fms.html", "💹"),
            NavItem("Financial Audit",                 "bsnlset/fau.html", "🔍"),
            NavItem("Direct Taxes",                    "bsnlset/fdt.html", "🏛️"),
            NavItem("Indirect Taxes (GST/Customs)",    "bsnlset/idt.html", "📜"),
            NavItem("Commercial Laws",                 "bsnlset/fcl.html", "⚖️"),
            NavItem("Public Finance & Govt Accounts",  "bsnlset/pfg.html", "🏦"),
            NavItem("Banking & Financial Institutions","bsnlset/bfi.html", "🏧"),
            NavItem("Economics & Budget",              "bsnlset/ebe.html", "💼"),
            NavItem("Financial QM & Operations Research","bsnlset/fqm.html","📐"),
            NavItem("Financial BC – Basic Concepts",   "bsnlset/fbc.html", "📚")
        ),
        "🧮 Quantitative Aptitude" to listOf(
            NavItem("Number Systems & Arithmetic",     "bsnlset/ns.html",  "🔢"),
            NavItem("Advanced Data Interpretation",    "bsnlset/adn.html", "📉")
        ),
        "🧩 Logical Reasoning" to listOf(
            NavItem("Logical Reasoning",               "bsnlset/lr.html",  "🧩"),
            NavItem("Non-Verbal Analysis",             "bsnlset/nva.html", "🔍")
        ),
        "🅰️ English" to listOf(
            NavItem("Grammar & Vocabulary",            "bsnlset/egv.html", "📝"),
            NavItem("Reading & Understanding",         "bsnlset/eru.html", "📖")
        ),
        "🇮🇳 GK & Current Affairs" to listOf(
            NavItem("General Knowledge & Science",     "bsnlset/gks.html", "🌏"),
            NavItem("BSNL Organisation & Services",    "bsnlset/bsnl.html","📡")
        ),
        "📝 Mock Tests — Telecom" to listOf(
            NavItem("Mock Test Hub (Telecom)",         "bsnlset/mocktest/index.html","📋"),
            NavItem("Set A — Full Test",               "bsnlset/mocktest/seta.html","📄"),
            NavItem("Set B — Full Test",               "bsnlset/mocktest/setb.html","📄"),
            NavItem("Set C — Full Test",               "bsnlset/mocktest/setc.html","📄"),
            NavItem("Set D — Full Test",               "bsnlset/mocktest/setd.html","📄")
        ),
        "📝 Mock Tests — Finance" to listOf(
            NavItem("Mock Test Hub (Finance)",         "bsnlset/mocktestf/index.html","📋"),
            NavItem("Finance Set A",                   "bsnlset/mocktestf/seta.html","📄"),
            NavItem("Finance Set B",                   "bsnlset/mocktestf/setb.html","📄")
        )
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "BSNL SET 2026"

        drawerLayout = binding.drawerLayout
        navView       = binding.navView

        // Drawer toggle
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, binding.toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)
        buildNavigationMenu()

        // WebView setup
        val wv = binding.webView
        with(wv.settings) {
            javaScriptEnabled        = true
            domStorageEnabled        = true
            allowFileAccess          = true
            allowContentAccess       = true
            loadsImagesAutomatically = true
            mixedContentMode         = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode                = WebSettings.LOAD_DEFAULT
            setSupportZoom(true)
            builtInZoomControls   = true
            displayZoomControls   = false
            useWideViewPort        = true
            loadWithOverviewMode   = true
        }
        wv.setBackgroundColor(Color.parseColor("#f0f4fc"))

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                binding.progressBar.visibility = View.VISIBLE
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.progressBar.visibility = View.GONE
                // Inject back-button override for internal links
                view?.evaluateJavascript("""
                    (function(){
                        document.addEventListener('click', function(e){
                            var t = e.target.closest('a');
                            if(t && t.href && t.href.startsWith('file:///')){
                                e.preventDefault();
                                Android.navigateTo(t.getAttribute('href'));
                            }
                        });
                    })();
                """, null)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return when {
                    url.startsWith("file:///android_asset/") -> {
                        view?.loadUrl(url)
                        true
                    }
                    url.startsWith("https://examica.in") || url.startsWith("http://examica.in") -> {
                        // Open in external browser
                        try {
                            val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                            startActivity(i)
                        } catch (_: Exception) {}
                        true
                    }
                    url.startsWith("http") || url.startsWith("https") -> {
                        view?.loadUrl(url)
                        true
                    }
                    else -> false
                }
            }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                binding.progressBar.visibility = View.GONE
            }
        }

        // JS Bridge
        wv.addJavascriptInterface(object {
            @JavascriptInterface
            fun navigateTo(href: String) {
                runOnUiThread {
                    val path = href.removePrefix("file:///android_asset/")
                    loadPage(path)
                }
            }
        }, "Android")

        // Swipe-to-refresh
        binding.swipeRefresh.setColorSchemeColors(Color.parseColor("#0050e6"), Color.parseColor("#0098b8"))
        binding.swipeRefresh.setOnRefreshListener {
            wv.reload()
            binding.swipeRefresh.isRefreshing = false
        }

        // Load saved or default page
        val savedUrl = savedInstanceState?.getString("currentFile") ?: currentFile
        loadPage(savedUrl)
    }

    private fun buildNavigationMenu() {
        val menu = navView.menu
        menu.clear()
        var itemId = 1
        for ((sectionTitle, items) in navSections) {
            val group = menu.addSubMenu(sectionTitle)
            for (item in items) {
                val mi = group.add(0, itemId++, 0, "${item.icon} ${item.title}")
                mi.isCheckable = true
            }
        }
    }

    private fun getItemByMenuId(id: Int): NavItem? {
        var counter = 1
        for ((_, items) in navSections) {
            for (item in items) {
                if (counter == id) return item
                counter++
            }
        }
        return null
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun loadPage(assetPath: String) {
        currentFile = assetPath
        val url = "file:///android_asset/$assetPath"
        binding.webView.loadUrl(url)
        // Update toolbar title from path
        val title = navSections
            .flatMap { it.second }
            .find { it.file == assetPath }?.title ?: "BSNL SET 2026"
        supportActionBar?.title = title
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val navItem = getItemByMenuId(item.itemId)
        navItem?.let { loadPage(it.file) }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    override fun onBackPressed() {
        when {
            drawerLayout.isDrawerOpen(GravityCompat.START) -> drawerLayout.closeDrawer(GravityCompat.START)
            binding.webView.canGoBack() -> binding.webView.goBack()
            currentFile != "bsnlset/index.html" -> loadPage("bsnlset/index.html")
            else -> super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("currentFile", currentFile)
    }
}
