package com.rocketexamica.bsnlset

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val rocket = findViewById<TextView>(R.id.splashRocket)
        val title  = findViewById<TextView>(R.id.splashTitle)
        val sub    = findViewById<TextView>(R.id.splashSub)
        val brand  = findViewById<TextView>(R.id.splashBrand)

        val fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in)
        rocket.startAnimation(fadeIn)
        title.startAnimation(fadeIn)
        sub.startAnimation(fadeIn)
        brand.startAnimation(fadeIn)

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1800)
    }
}
