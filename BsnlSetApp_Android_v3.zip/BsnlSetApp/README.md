# BSNL SET 2026 — Android App
**Rocket Examica | Mahakumbrix Innovation**

A full offline Android app for BSNL SET 2026 exam preparation, powered by a WebView that loads all 55+ HTML study pages locally.

---

## 📱 App Features
- 🚀 Splash screen with Rocket Examica branding
- 📂 Navigation Drawer with 10 sections & 55+ pages
- 🌐 WebView-based — all HTML loads **100% offline** (no internet needed)
- 🔄 Swipe-to-refresh support
- ⬅️ Back button navigates WebView history → Home → Exit
- 📡 External links (examica.in) open in browser

## 📚 Content Sections
| Section | Topics |
|---|---|
| 🏠 Home | Dashboard, Mock Test Hub |
| 📡 Telecom | BWC, GSM/5G, OFC, Switching, IP, Security, Cloud, IoT, Satellite, PM, BE |
| ⚡ Electronics | Analog/Digital, Circuits, Solid State, Comms, Control, Power, EM, Microprocessors... |
| 💰 Finance | Accounting, Tax, Audit, Banking, Economics, GST, Financial Management... |
| 🧮 Quant | Number Systems, Data Interpretation |
| 🧩 Reasoning | Logical, Non-Verbal |
| 🅰️ English | Grammar, Reading |
| 🇮🇳 GK | General Knowledge, BSNL Org |
| 📝 Mock Tests (Telecom) | 4 full sets (A, B, C, D) |
| 📝 Mock Tests (Finance) | 2 full sets (A, B) |

---

## 🛠️ Setup in Android Studio

### Step 1 — Open Project
1. Open **Android Studio** (Hedgehog 2023.1 or later recommended)
2. Click **File → Open** and select the `BsnlSetApp` folder
3. Let Android Studio **sync Gradle** (it will auto-download Gradle 8.2)

### Step 2 — Set SDK Path
Edit `local.properties` and set your Android SDK path:
```
sdk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk   (Windows)
sdk.dir=/Users/YourName/Library/Android/sdk                   (macOS)
sdk.dir=/home/YourName/Android/Sdk                             (Linux)
```

### Step 3 — Build & Run
- Connect an Android device (API 24+) or start an emulator
- Click **Run ▶** or press `Shift+F10`
- Or build APK: **Build → Build Bundle(s)/APK(s) → Build APK(s)**

### Step 4 — Get APK
The APK will be at:
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## 📋 Requirements
- **minSdk**: 24 (Android 7.0)
- **targetSdk**: 34 (Android 14)
- **Android Studio**: Hedgehog (2023.1.1) or newer
- **Gradle**: 8.2 (auto-downloaded)

---

## 🏗️ Project Structure
```
BsnlSetApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/rocketexamica/bsnlset/
│   │   │   ├── SplashActivity.kt
│   │   │   └── MainActivity.kt
│   │   ├── assets/bsnlset/          ← All 55+ HTML files
│   │   │   ├── index.html
│   │   │   ├── bwc.html, gsm.html ...
│   │   │   ├── mocktest/
│   │   │   └── mocktestf/
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   ├── drawable/
│   │   │   ├── values/
│   │   │   └── mipmap-*/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle/wrapper/
```

---

*Built by Mahakumbrix Innovation · Rocket Examica · 2026*
